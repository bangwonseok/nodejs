const Sequelize = require('sequelize');		// Sequelize 생성자

const env = process.env.NODE_ENV || 'development';
const config = require("../config/config")[env];	//	1) 각 운영 상황에 따른 DB계정 설정 2) "../config/config.json"	<- json 생략 가능

const sequelize = new Sequelize(config.database, config.username, config.password, config);

/**
	sequelize 인스턴스
				1) DB 연결 .sync
				2) SQL 실행 . query
								-> Sequelize.QureyTypes - SELECT, UPDATE, INSERT, DELETE
	
	Sequelize
*/
const db= {};
db.sequelize = sequelize;
db.Sequelize = Sequelize;

module.exports = db;