const member = require('../models/member');	// 55
const express = require('express');
const router = express.Router();

router.get("/", async (req, res) =>{
	const list = await member.getList();	//55
	return res.render("main/index", {list});
});

module.exports = router;