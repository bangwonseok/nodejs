const express = require('express');
const path= require('path');
const morgan = require('morgan');
const dotenv = require('dotenv');
const cookieParser = require('cookie-parser');
const session = require('express-session');
const nunjucks = require('nunjucks');
const logger = require('./lib/logger');

/* 라우터 */
const indexRouter = require('./routes');
const boardRouter = require('./routes/board');
const app = express();



app.set('PORT', process.env.PORT || 3000);
app.set("view engine", "html");

nunjucks.configure(path.join(__dirname, "views"), {
	express : app,
	watch : true,
});

dotenv.config(); // .env -> process.env 하위 속성으로 추가

app.use(morgan('dev'));
app.use(express.json());
app.use(express.urlencoded({extemded : false}));
app.use("/", express.static(path.join(__dirname, 'public')));
app.use(cookieParser(process.env.COOKIE_SECRET));
app.use(session({
	resave : false,
	saveUninitialized : true,
	secret : process.env.COOKIE_SECRET,
	name : "yhessionid",
}));

/** 라우터 등록 */
app.use(indexRouter);
app.use("/board", boardRouter);

app.use((req, res, next) =>{ // 없는 페이지 처리 라우터
	//next(에러객체), throw 에러객체 // 404 Status Code - NOT FOUND
	const error = new Error(`${req.url}는 없는 페이지 입니다.`);
	error.status = 404;
	next(error);
});

app.use((err, req, res, next) => { // 오류처리 미들웨어(라우터)
	// next(에러객체), throw 에러객체
	const data= {
		message : err.message,
		status : err.status || 500,
		stack : err.stack,
	};
	
	/** 로거 */
	logger(`[${data.status}]${data.message}`, 'error');
	logger(data.stack, 'error');
	
	if(process.env.NODE_ENV === 'production') {
		delete data.stack;
	}
	
	return res.status(data.status).render('error',data);
	
});

app.listen(app.get('PORT'), ()=>{
	console.log(app.get('PORT'), "번 포트에서 서버 대기중...");
});
/*
app.use((req, res, next) =>{	// 모든 메서드, 모든 요청 URL에 해당 하는 미들웨어
	// 공통 라우터 또는 공통 미들웨어
	// 사용자가 어떤 요청을 하든 항상 거쳐가는 미들웨어, 라우터
	
	// return res.send(req.method + " : " + req.url);
	console.log(req.method + " : " + req.url);
	
	next();
});

app.get("/test1", (req, res) => {
	return res.send("테스트 라우터1");
});

app.get("/test2", (req, res) => {
	return res.send("테스트 라우터2");
});

app.use((req, res, next) => { // 공통 미들웨어 - 모든 메서드, 모든 요청
	return res.send("없는 페이지 처리 미들웨어");
});


app.listen(app.get('PORT'), ()=>{
	console.log(app.get('PORT'), "번 포트에서 서버 대기중...");
});
*/

/*
app.get("/", (req, res, next) => {
	console.log("미들웨어1");
	next();
	// 미들웨어1
}, (req, res, next) => {
	console.log("미들웨어2");
	next();
	// 미들웨어2
	// return res.send("출력 - 미들웨어2"); // response가 완료
});

app.get("/", (req, res, next) =>{
	console.log("미들웨어3");
	next();
});

app.get("/", (req, res, next) => {
	console.log("미들웨어4");
	return res.send("응답완료 - 미들웨어4에서");
});

app.get("/", (req, res, next) => {
	console.log("미들웨어5");
});

app.listen(app.get('PORT'), ()=>{
	console.log(app.get('PORT'), "번 포트에서 서버 대기중...");
});
*/